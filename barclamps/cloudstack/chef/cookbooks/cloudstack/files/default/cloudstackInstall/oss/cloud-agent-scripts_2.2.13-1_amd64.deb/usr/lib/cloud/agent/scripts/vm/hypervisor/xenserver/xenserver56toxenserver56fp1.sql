update vm_instance set guest_os_id=98 where guest_os_id in (111, 113, 134, 121, 136) and hypervisor_type='XenServer';
update vm_instance set guest_os_id=99 where guest_os_id in (112, 114, 135, 126, 137) and hypervisor_type='XenServer';
update vm_template set guest_os_id=98 where guest_os_id in (111, 113, 134, 121, 136) and hypervisor_type='XenServer';
update vm_template set guest_os_id=99 where guest_os_id in (112, 114, 135, 126, 137) and hypervisor_type='XenServer';
