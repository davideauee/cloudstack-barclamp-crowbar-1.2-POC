ALTER TABLE `cloud`.`user` DROP KEY `i_user__username__removed`;

